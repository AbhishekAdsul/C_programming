#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node *next;
};

void displaylist(struct node *head);
void createlist(struct node *head);
void deletelist(struct node *head);

int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------------------------------\n");
    printf("Linked Lists | Deleting element from linked list\n\n");
    
    struct node *n1,*n2,*n3,*n4;
    n1=(struct node*)malloc(sizeof(struct node));
    n2=(struct node*)malloc(sizeof(struct node));
    n3=(struct node*)malloc(sizeof(struct node));
    n4=(struct node*)malloc(sizeof(struct node));

    n1->data=10;
    n2->data=20;
    n3->data=30;
    n4->data=40;

    n1->next=n2;
    n2->next=n3;
    n3->next=n4;
    n4->next=0;

    createlist(n1);
    displaylist(n1);
    deletelist(n1);
    displaylist(n1);

    
    printf("\n\n");
    return 0;
}
void displaylist(struct node *head)
{
    struct node *current;
    current = head;
    printf("\nLinked list -->");
    while(current!=0)
    {
        printf("%d",current->data);
        current=current->next;
        if(current!=0)
        {
            printf(" : ");
        }
    }
}

void createlist(struct node *head)
{
    struct node *current;
    current = head;
    int size, i=1;
    printf("\nEnter number of elements: ");
    scanf("%d",&size);
    while(i<=size)
    {
        printf("Enter elements %d: ",i);
        scanf("%d",&current->data);
        if(i==size)
        {
            current->next=0;
        }
        else
        {
            current->next=(struct node*)malloc(sizeof(struct node));
            current = current->next;
        }

        i++;
    }    
}

void deletelist(struct node *head)
{
    struct node *current;
    current = head;
    int length=0,position,i=1;

    while(current!=0)
    {
        length++;
        current = current->next;
    }
    current = head;

    printf("\n\nEnter position to delete (1-%d): ",length);
    scanf("%d",&position);

    struct node *trace;
    trace = (struct node*)malloc(sizeof(struct node));
    
    if(position<=1)                 /*delete at head*/
    {
        position = 1;
        trace = current->next;
        current->data = trace->data;
        current->next = trace->next;
        free(trace);

    }
    else if(position >= length)     /*insert at tail*/
    {
        position = length;
        while(current->next!=0)
        {
            trace =current;
            current = current->next;
        }
        trace->next = 0;
        free(current);
    }
    else                            /*insert at random*/
    {
        while(i<position)
        {
            trace = current;
            current = current->next;
            i++;
        }
        trace->next = current->next;
        free(current);
    }

}