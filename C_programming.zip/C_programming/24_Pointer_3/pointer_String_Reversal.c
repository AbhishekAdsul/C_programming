#include<stdio.h>
#include<stdlib.h>
#include<string.h>


void reverse(char *ptrarrname);

int main()
{
    char arrname[30];
    char *ptrarrname=arrname;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------------\n");
    printf("Pointer | String Reversal\n\n");
    printf("Enter a string: \n");
    fgets(ptrarrname,30,stdin);
    reverse(ptrarrname);
    printf("\nReverse String: %s",ptrarrname);

    printf("\n\n");
    return 0;
}
void reverse(char *ptrarrname)
{
    char *ptrreverse;
    int length;
    char temp;
    length=strlen(ptrarrname);
    ptrreverse=ptrarrname+length-1-1;
    while(ptrarrname<ptrreverse)
    {
        temp=*ptrarrname;
        *ptrarrname=*ptrreverse;
        *ptrreverse=temp;

        ptrarrname++;
        ptrreverse--;
    }
    
}