#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void swapbyvalue(int a, int b);
void swapbyreferance(int *ptra, int *ptrb);
int main()
{
    int a=22;
    int *ptra=&a;
    int b=45;
    int *ptrb=&b;

    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------------\n");
    printf("Pointer | Call by referance\n\n");
    printf("Enter a string: \n");
    printf("Original\n");
    printf("a=%d\n",a);
    printf("b=%d\n",b);

    printf("\nCall by value\n");
    swapbyvalue(a,b);
    printf("a=%d\n",a);
    printf("b=%d\n",b);

    printf("\nCall by referance\n");
    swapbyreferance(ptra,ptrb);
    printf("a=%d\n",a);
    printf("b=%d\n",b);


    return 0;

}

void swapbyvalue(int a, int b)
{
    int temp; 
    temp=a;
    a=b;
    b=temp;
}

void swapbyreferance(int *ptra, int *ptrb)
{
    int temp;
    temp=*ptra;
    *ptra=*ptrb;
    *ptrb=temp;
}