#include<stdio.h>
#include<stdlib.h>
int main()
{
    int num=0,max,sum=0;
    system("cls");
    printf("Abhishek V Adsul\n");
    printf("--------------------------\n");
    printf("While loop | Sum of even numbers\n\n");
    printf("Enter the number: ");
    scanf("%d",&max);
    while(num<=max)
    {
        if(num%2==0)
        {
            sum=sum+num;
            printf("\n%2d | Sum = %d",num,sum);
        }
        num++;
    }
    printf("\n\n");
    return 0;
}