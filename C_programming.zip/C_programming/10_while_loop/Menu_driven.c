//Menu driven program using switch cases and while loop till user decides to exit

#include<stdio.h>
#include<stdlib.h>
int main()
{
    int repeat=1;
    while(repeat!=0)
    {
    int a,b,choice,c;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------\n");
    printf("Switch case Menu driven\n\n");
    printf("Enter a: ");
    scanf("%d",&a);
    printf("Enter b: ");
    scanf("%d",&b);
    printf("\n------------------------\n");
    printf("MENU OPTIONS:\n");
    printf("1:Addition\n");
    printf("2:Substraction\n");
    printf("3:Multiplication\n");
    printf("4:Division\n");
    printf("5:end\n");
    printf("--------------------------\n\n");
    printf("Enter your option:");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        {
            c=a+b;
            printf("Addition is: %d\n",c);
            break;
        }
        case 2:
        {
            c=a-b;
            printf("Substraction is: %d\n",c);
            break;
        }
        case 3:
        {
            c=a*b;
            printf("Multiplication is: %d\n",c);
            break;
        }
        case 4:
        {
            c=a/b;
            printf("Quotiont is: %d\n",c);
            c=a%b;
            printf("Remainder is: %d\n",c);
            break;
        }
        case 5:
        {
            printf("Thank you\n\n");
            break;
        }
        default:
        {
            printf("You entered option is not in menu\n\n");
        }
    }
    printf("_______________________________________");
    printf("\nDo you want to repeat (Yes=1 | No=0): ");
    scanf("%d",&repeat);
    }
    return 0;
}
