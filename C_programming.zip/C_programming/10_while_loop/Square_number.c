//Calculate square till user decides to exit
#include<stdio.h>
#include<stdlib.h>
int main()
{
    int num,square;
    system("cls");
    printf("Abhishek V Adsul\n");
    printf("-----------------------------\n");
    printf("While loop | Square of number\n\n");
    printf("Enter the number: ");
    scanf("%d",&num);
    square=num*num;
    printf("Square of number %d is: %d\n",num,square);
    while(num!=0)
    {
        printf("\nEnter another number (enter 0 to exit): ");
        scanf("%d",&num);
        if(num!=0)
        {
        square=num*num;
        printf("\nSquare of number %d is: %d",num,square);
        }
    }
    printf("\n\n");
    return 0;
}