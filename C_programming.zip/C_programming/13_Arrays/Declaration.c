#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i;
    int arrint[5]={1,2,3,4,5};
    float arrfloat[5]={1.2,2.3,3.4,4.5,5.6};
    char arrchar[8]={'A','B','H','I','S','H','E','K'};
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("Arrays | Declaration of an array\n\n");
    for(i=0;i<5;i++)
    {
        printf("\narrint[%d]: %d",i,arrint[i]);
    }
    printf("\n");
    for(i=0;i<5;i++)
    {
        printf("\narrfloat[%d]: %2.1f",i,arrfloat[i]);
    }
    printf("\n");
    for(i=0;i<8;i++)
    {
        printf("\narrchar[%d]: %c",i,arrchar[i]);
    }
    printf("\n\n");
    return 0;

}