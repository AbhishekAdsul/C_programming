#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i;
    int arrint[5];
    float arrfloat[5];
    char arrchar[8];
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("Arrays | Declaration of an array\n\n");
    printf("Enter 5 integer elements:\n");
    for(i=0;i<5;i++)
    {
        printf("arrint[%d]: ",i+1);
        scanf("%d",&arrint[i]);
    }
    for(i=0;i<5;i++)
    {
        printf("\narrint[%d]: %d",i+1,arrint[i]);
    }

    printf("\n\nEnter 5 float elements:\n");
    for(i=0;i<5;i++)
    {
        printf("arrint[%d]: ",i+1);
        scanf("%f",&arrfloat[i]);
    }
    for(i=0;i<5;i++)
    {
        printf("\narrint[%d]: %2.1f",i+1,arrfloat[i]);
    }
    printf("\n\n");
    return 0;
}