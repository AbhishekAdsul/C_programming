#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i;
    int arrint[5];
    int choice,min,max,sum=0,avg=0;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("Arrays | Declaration of an array\n\n");
    printf("Enter 5 integer elements:\n");
    for(i=0;i<5;i++)
    {
        printf("arrint[%d]: ",i+1);
        scanf("%d",&arrint[i]);
    }
    do{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("Arrays | Declaration of an array\n\n");
    printf("\nyour entered values are: \n");
    for(i=0;i<5;i++)
    {
        printf("\narrint[%d]: %d",i+1,arrint[i]);
    }
    printf("\n\nMENU OPTIONS:\n");
    printf("1:Minimum Number\n");
    printf("2:Maximum Number\n");
    printf("3:Sum\n");
    printf("4:Average\n");
    printf("5:Exit\n\n");
    printf("Enter your choice: ");
    scanf("%d",&choice);
    
    switch(choice)
    {
        case 1 :
        min=arrint[0];
        for(i=0;i<5;i++){
        if(arrint[i]<min)
        {
            min=arrint[i];

        }
        }
        printf("Result | Minimum Number: %d",min);
        break;

        case 2 :
        max=arrint[0];
        for(i=0;i<5;i++){
        if(arrint[i]>max)
        {
            max=arrint[i];

        }
        }
        printf("Result | Maximum Number: %d",max);
        break;

        case 3 :
        for(i=0;i<5;i++)
        {
            sum=sum+arrint[i];
        }
        printf("Result | Sum: %d",sum);
        break;

        case 4:
        for(i=0;i<5;i++)
        {
            sum=sum+arrint[i];
        }
        avg=sum/5;
        printf("Result | Average: %d",avg);
        break;

        case 5:
        printf("Thank you\n\n");

        default:
        printf("Entered choice is not in menu\n\n");

    }
    printf("\n");
    getchar();
    getchar();
    }while(choice!=5);
    return 0;
}