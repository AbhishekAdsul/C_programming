#include<stdio.h>
#include<stdlib.h>

int main()
{
    char arrname[30];
    char *ptrarrname=arrname;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------\n");
    printf("Pointers | Accessing a String\n\n");
    printf("Enter a string: \n");
    fgets(ptrarrname,30,stdin);
    printf("\n");
    while(*ptrarrname!='\0')
    {
        printf("%c",*ptrarrname++);
    }
    printf("\n\n");
    return 0;
    

}
