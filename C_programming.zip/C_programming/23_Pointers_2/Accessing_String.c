#include<stdio.h>
#include<stdlib.h>

int main()
{
    char arrname[30]={"CHATRAPATI SHIVAJI MAHARAJ"};
    char *ptrarrname=arrname;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------\n");
    printf("Pointers | Accessing a String\n\n");
    while(*ptrarrname!='\0')
    {
        printf("%c\n",*ptrarrname++);
    }
    printf("\n\n");
    return 0;
    

}
