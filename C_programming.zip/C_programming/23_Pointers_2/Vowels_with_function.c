#include<stdio.h>
#include<stdlib.h>
int getcount(char *ptrarrname);
int main()
{
    char arrname[30];
    char *ptrarrname=arrname;
    int vowels=0;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------------------\n");
    printf("Pointers | Count Vowels in string\n\n");
    printf("Enter a string: \n");
    fgets(ptrarrname,30,stdin);
    printf("\n");
    vowels=getcount(ptrarrname);
    printf("Vowels: %d",vowels);
    printf("\n\n");
    return 0;
}
int getcount(char *ptrarrname)
{
    int vowelcount=0;
    while(*ptrarrname!='\0')
    {
        switch(*ptrarrname++)
        {
            case 'a':
            case 'A':
            case 'e':
            case 'E':
            case 'i':
            case 'I':
            case 'o':
            case 'O':
            case 'u':
            case 'U':
            vowelcount++;
            break;
        }
    }
    return vowelcount;
}