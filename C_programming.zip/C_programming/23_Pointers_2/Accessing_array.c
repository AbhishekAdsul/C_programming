#include<stdio.h>
#include<stdlib.h>

int main()
{
    int arrnum[10]={10,20,30,40,50,60,70,80,90,99};
    int *ptrarrnum = arrnum;

    int arrnum2[10]={10,20,30,40,50,60,70,80,90,99};
    int *ptrarrnum2 = arrnum2;

    int i,count=10;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------\n");
    printf("Pointers | Accessing an array\n\n");
    printf("Using for loop\n");
    for(i=0;i<count;i++)
    {
        printf("%2d = %d\n",i+1,*ptrarrnum++);
    }
    printf("\nUsing while loop...\n");
    i=0;
    while(i<count)
    {
        printf("%d\n",*ptrarrnum2++);
        i++;
    }
    printf("\n\n");
    return 0;
    

}
