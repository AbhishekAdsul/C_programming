#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node *next;
};
void displaylist(struct node *head);
void createlist(struct node *head);
void searchlist(struct node *head);

int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------------\n");
    printf("Linked Lists | Searching of linked list\n\n");
    
    struct node *n1,*n2,*n3,*n4;
    n1=(struct node*)malloc(sizeof(struct node));
    n2=(struct node*)malloc(sizeof(struct node));
    n3=(struct node*)malloc(sizeof(struct node));
    n4=(struct node*)malloc(sizeof(struct node));

    n1->data=10;
    n2->data=20;
    n3->data=30;
    n4->data=40;

    n1->next=n2;
    n2->next=n3;
    n3->next=n4;
    n4->next=0;

    createlist(n1);
    displaylist(n1);
    searchlist(n1);
    
    printf("\n\n");
    return 0;
}
void displaylist(struct node *head)
{
    struct node *current;
    current = head;
    printf("\nLinked list -->");
    while(current!=0)
    {
        printf("%d",current->data);
        current=current->next;
        if(current!=0)
        {
            printf(" : ");
        }
    }
}

void createlist(struct node *head)
{
    struct node *current;
    current = head;
    int size, i=1;
    printf("\nEnter number of elements: ");
    scanf("%d",&size);
    while(i<=size)
    {
        printf("Enter elements %d: ",i);
        scanf("%d",&current->data);
        if(i==size)
        {
            current->next=0;
        }
        else
        {
            current->next=(struct node*)malloc(sizeof(struct node));
            current = current->next;
        }

        i++;
    }    
}
void searchlist(struct node *head)
{
    struct node *current;
    current = head;
    int count=0;
    char value;
    printf("\n\nEnter the element to search: ");
    scanf("%d",&value);
    while(current!=0)
    {
        if(current->data==value)
        {
            count++;
        }
        current=current->next;
    }
    printf("No of occurances of No.%d are: %d",value,count);
}