#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    float p,r,n,si,tds,final;
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("Simple Interest\n\n");
    printf("Enter Details:\n");
    printf("Principal\t\t| ");
    scanf("%f",&p);
    printf("No. of years\t\t| ");
    scanf("%f",&n);
    printf("Rate of interest\t| ");
    scanf("%f",&r);
    si=p*n*r/100;
    tds=0.1*si;
    final=p+si-tds;
    printf("\n-----------------Results-------------------\n\n");
    printf("Simple interest before tax\t\t\t| %8.0f\n",si);
    printf("TDS(10 percent tax on simple interest)\t\t| %8.0f\n",tds);
    printf("Simple interest afer applying tax\t\t| %8.0f\n",si-tds);
    printf("Final amount on hand\t\t\t\t| %8.0f\n\n",final);
    return 0;


}