#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("----------------------\n");
    printf("Salary slip generation\n\n");
    float basic,da,hra,conv,med,gross,esic,pf,netpretax,tds,salary;
    printf("Enter the basic salary: ");
    scanf("%f",&basic);
    da=0.1*basic;
    hra=0.5*basic+da;
    conv=1600;
    med=1250;
    gross=basic+da+hra+conv+med;
    esic=0.0475*gross;
    pf=0.12*basic;
    netpretax=gross-esic-pf;
    tds=0.05*netpretax;
    salary=netpretax-tds;
    printf("_________________________________________________________________________________\n");
    printf("|\t\t\t\tSalary Slip Generation\t\t\t\t|\n");
    printf("|_______________________________________________________________________________|\n");
    printf("|Basic\t\t\t\t|\t\t%8.0f|\t\t\t|\n",basic);
    printf("|DA\t\t\t\t|\t\t%8.0f|10 %% basic\t\t|\n",da);
    printf("|HRA\t\t\t\t|\t\t%8.0f|50 %% basic+DA\t\t|\n",hra);
    printf("|Conveyance\t\t\t|\t\t%8.0f|Fixed\t\t\t|\n",conv);
    printf("|Medical\t\t\t|\t\t%8.0f|Fixed\t\t\t|\n",med);
    printf("|Gross\t\t\t\t|\t\t%8.0f|\t\t\t|\n",gross);
    printf("|-------------------------------|-----------------------|-----------------------|\n");
    printf("|ESIC\t\t\t\t|\t\t%8.0f|4.75 %% of gross\t|\n",esic);
    printf("|Provident fund\t\t\t|\t\t%8.0f|12 %% of basic\t\t|\n",pf);
    printf("|Net before tax\t\t\t|\t\t%8.0f|\t\t\t|\n",netpretax);
    printf("|-------------------------------|-----------------------|-----------------------|\n");
    printf("|TDS\t\t\t\t|\t\t%8.0f|5 %% of net before tax\t|\n",tds);
    printf("|-------------------------------|-----------------------|-----------------------|\n");
    printf("|Salary in hand\t\t\t|\t\t%8.0f|\t\t\t|\n",salary);
    printf("|_______________________________________________________________________________|\n\n");

    return 0;
}