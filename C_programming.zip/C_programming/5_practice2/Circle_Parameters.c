#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("Circle_parameters\n\n");

    const float pi=3.142;
    float r,d,c,a;
    printf("Enter the radius of circle: ");
    scanf("%f",&r);
    printf("----------------------------\n");
    printf("Results....\n");
    d=2*r;
    c=2*pi*r;
    a=pi*r*r;
    printf("Diameter of circle is: %.2f\n",d);
    printf("Circumference of circle is: %.2f\n",c);
    printf("Area of the circle is: %.2f\n\n",a);
    
    return 0;
}