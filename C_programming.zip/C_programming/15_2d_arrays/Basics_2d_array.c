#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,j;
    int arrnum[2][3];
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("------------------------------\n");
    printf("2D Arrays | Basics of 2D array\n\n");
    printf("Enter the elements of the 2D array....\n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("Enter [%d][%d]: ",i,j);
            scanf("%d",&arrnum[i][j]);
        }
        printf("\n");
    }
    printf("\nYour entered elements are: \n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d ",arrnum[i][j]);
        }
        printf("\n");
    }

    printf("\n\n");
    return 0;
}