#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    int i,number,count;
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------\n");
    printf("for loop | Multiply table\n\n");
    printf("Enter the number: ");
    scanf("%d",&number);
    printf("Enter the count of table: ");
    scanf("%d",&count);
    for(i=1;i<=count;i++)
    {
        printf("%d * %d = %d\n",number,i,number*i);
    }
    return 0;
}