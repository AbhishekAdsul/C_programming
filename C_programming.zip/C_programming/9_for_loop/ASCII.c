#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    char i;
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("\tASCII\t\n");
    for(i='a';i<='z';i++)
    {
        printf("%c\t|\t%d\t\n",i,i);
    }
    printf("\n");
    for(i='A';i<='Z';i++)
    {
        printf("%c\t|\t%d\t\n",i,i);
    }
    printf("\n");
    

    return 0;
}