#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,j,count,num,sum=0,avg=0,max=0,balls=0,overs=0,target,max_over,total_balls;
    float rr,required_rr;
    system("cls");
    printf("+----------------------------------+\n");
    printf("|C | Abhishek V Adsul              |\n");
    printf("|__________________________________|\n");
    printf("|Score board example using for loop|\n");
    printf("+----------------------------------+\n\n");

    printf("Enter total overs to be played: ");
    scanf("%d",&count);
    for(i=0;i<count;i++)
    {
        printf("\nEnter the runs of %d over: ",i+1);
        scanf("%d",&num);
        sum=sum+num;
        avg=sum/(i+1);
        if(max<num)
        {
            max=num;
            max_over=i+1;
        }

        overs=(i+1);
        balls=(i+1)*6;
        rr=(float)sum/balls*100;
        printf("+-------------------------------------------------------------------------------------------------------------------------------------+\n");
        printf("|\t\t\t\t\t\t\tCricket Match Score board\t\t\t\t\t\t\t|\n");
        printf("|_____________________________________________________________________________________________________________________________________|\n");
        printf("|Overs: %d\t|Total Runs scored: %d\t\t|Average: %d\t\t|Max Runs %d in %d over\t\t |Current Run Rate: %4.2f\t|\n",overs,sum,avg,max,max_over,rr);
        printf("|_____________________________________________________________________________________________________________________________________|\n");
    }

    printf("\n\n");
    target=sum+1;
    total_balls=count*6;
    required_rr=(float)target/balls*100;
    
    printf("+-----------------------------------------------------------------------+\n");
    printf("|\t\t\t\tGAME OVER\t\t\t\t|\n");
    printf("|_______________________________________________________________________|\n");
    printf("|Target: %d\t|Out of balls: %d\t|Required Run Rate: %4.2f\t|\n",target,total_balls,required_rr);
    printf("|_______________________________________________________________________|\n\n");

    return 0;
}