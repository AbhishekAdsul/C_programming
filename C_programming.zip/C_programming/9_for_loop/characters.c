#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    char i;
    printf("C | Abhishek V Adsul\n");
    printf("----------------------------\n");
    printf("for loop | a to z characters\n\n");
    for(i='a';i<='z';i++)
    {
        printf("%c\n",i);
    }
    printf("\n");
    return 0;

}