#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------\n");
    printf("Exchange without using temp\n\n");

    int num1,num2;
    printf("Enter first number: ");
    scanf("%d",&num1);
    printf("Enter second number: ");
    scanf("%d",&num2);

    num1=num1+num2;
    num2=num1-num2;
    num1=num1-num2;

    printf("-------------------------------------------------------------\n");
    printf("Results....\n");
    printf("Numbers after exchange without using the temp(third variable)\n");
    printf("The first number is: %d\n",num1);
    printf("The second number is: %d\n\n",num2);
    
}