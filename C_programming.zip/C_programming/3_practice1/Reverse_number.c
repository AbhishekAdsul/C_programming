#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------\n");
    printf("Reverse 5 digit number\n\n");

    int num,rem,rev=0;
    printf("Enter the 5 digit number: ");
    scanf("%d",&num);

    rem=num%10;
    rev=rev+rem*10000;
    num=num/10;

    rem=num%10;
    rev=rev+rem*1000;
    num=num/10;

    rem=num%10;
    rev=rev+rem*100;
    num=num/10;

    rem=num%10;
    rev=rev+rem*10;
    num=num/10;

    rem=num%10;
    rev=rev+rem*1;
    num=num/10;
    
    printf("-------------------------\n");
    printf("Result.....\n");
    printf("The reverse_number is: %d\n\n",rev);
    return 0;
}