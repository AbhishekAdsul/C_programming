#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------\n");
    printf("Sum and Average\n\n");

    int num1,num2,num3,sum,avg;
    printf("Enter first number:");
    scanf("%d",&num1);
    printf("Enter second number:");
    scanf("%d",&num2);
    printf("Enter third number:");
    scanf("%d",&num3);
    sum=num1+num2+num3;
    avg=sum/3;
    printf("-----------------------\n");
    printf("Results......\n");
    printf("Sum of the given three numbers are: %d\n",sum);
    printf("Average of the given numbers are: %d\n\n",avg);
    

}