#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------\n");
    printf("Exchange using temp\n\n");

    int num1,num2,temp;
    printf("Enter the first number: ");
    scanf("%d",&num1);
    printf("Enter the second number: ");
    scanf("%d",&num2);
    temp=num1;
    num1=num2;
    num2=temp;
    printf("---------------------------\n");
    printf("Results.....\n");
    printf("Numbers after exchange using temperary variable:\n");
    printf("The first number is: %d\n",num1);
    printf("The second number is: %d\n\n",num2);
    return 0;
}