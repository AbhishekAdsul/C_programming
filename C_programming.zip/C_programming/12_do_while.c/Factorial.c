#include<stdio.h>
#include<stdlib.h>
int main()
{
    int num,temp,fact=1;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("------------------------------\n");
    printf("do while | Factorial of number\n\n");
    printf("Enter the number: ");
    scanf("%d",&num);
    temp=num;
    if((num!=0)||(num!=1))
    {
     do
        {
        fact=fact*num;
        num--;
        } while (num>0);
    printf("Factorial of the number %d is: %d",temp,fact);
    }
    return 0;
}