#include<stdio.h>
#include<stdlib.h>
int main()
{
    int balance=100000,tamount=0,choice=0;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("do while | ATM Withdrawal Machine\n");
    do{
    printf("\n\nMENU OPTIONS:\n");
    printf("1:Withdrawal Cash | 2:Exit\n\n");
    printf("Enter your choice: ");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        {
            printf("Your current bank balance: %d",balance);
            printf("\nEnter amount to withdrawal: ");
            scanf("%d",&tamount);
            if(tamount<=balance)
            {
                balance=balance-tamount;
                printf("\nTransaction successfull...Collect your cash\n");
                printf("Updated amount: %d",balance);
            }
            else
            {
                printf("Transaction Declined...Insufficient fundns\n");
            }
            break;
        }
        case 2:
        {
            printf("Thank you.... visit again\n");
            break;
        }
        default:
        {
            printf("Invalid choice selection\n\n");
        }
    }
 }while(choice!=2);

return 0;

}