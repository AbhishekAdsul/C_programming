#include<stdio.h>
#include<stdlib.h>
int factorial(int);
int main()
{
    int x;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("------------------------------\n");
    printf("Function | Factorial of number\n\n");
    x=factorial(8);
    printf("Factorial of 8 is: %d\n",x);

    x=factorial(9);
    printf("Factorial of 9 is: %d\n",x);

    x=factorial(10);
    printf("Factorial of 10 is: %d\n",x);

    printf("\n\n");
    return 0;
}
int factorial(int num)
{
    int fact=1,i;
    for(i=1;i<=num;i++)
    {
        fact=fact*i;
    }
    return fact;
}