#include<stdio.h>
#include<stdlib.h>
int maximum(int, int, int);
int minimum(int, int, int);
int sum(int ,int ,int);
float average(int, int, int);
int main()
{
    int a,b,c,intresult;
    float floatresult;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------\n");
    printf("Function | Min , Max , Sum , Avg\n\n");

    printf("Enter first number: ");
    scanf("%d",&a);
    printf("Enter first number: ");
    scanf("%d",&b);
    printf("Enter first number: ");
    scanf("%d",&c);
    intresult = maximum(a,b,c);
    printf("\nMaximum number is: %d",intresult);

    intresult = minimum(a,b,c);
    printf("\nMinimum number is: %d",intresult);

    intresult = sum(a,b,c);
    printf("\nSum of three numbers is: %d",intresult);

    floatresult = average(a,b,c);
    printf("\nAverage is: %.2f",floatresult);

    printf("\n\n");
    return 0;
}
int maximum(int a,int b,int c)
{
    int result;
    result=a;
    if(b>result)
    {
        result=b;
    }
    if(c>result)
    {
        result=c;
    }
    return result;
}

int minimum(int a,int b,int c)
{
    int result;
    result=a;
    if(b<result)
    {
        result=b;
    }
    if(c<result)
    {
        result=c;
    }
    return result;
}

int sum(int a,int b,int c)
{
    int result;
    result=a+b+c;
    return result;
}

float average(int a, int b, int c)
{
    float result;
    result=a+b+c;
    result=result/3;
    return result;
}