#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node *next;
};

void displaylist(struct node *head);

int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------------\n");
    printf("Linked Lists | Display list\n\n");
    
    struct node *n1,*n2,*n3,*n4;
    n1=(struct node*)malloc(sizeof(struct node));
    n2=(struct node*)malloc(sizeof(struct node));
    n3=(struct node*)malloc(sizeof(struct node));
    n4=(struct node*)malloc(sizeof(struct node));

    n1->data=10;
    n2->data=20;
    n3->data=30;
    n4->data=40;

    n1->next=n2;
    n2->next=n3;
    n3->next=n4;
    n4->next=0;

    displaylist(n1);
    
    printf("\n\n");
    return 0;
}

void displaylist(struct node *head)
{
    struct node *current;
    current = head;
    printf("\nLinked list -->");
    while(current!=0)
    {
        printf("%d",current->data);
        current=current->next;
        if(current!=0)
        {
            printf(" : ");
        }
    }
}