#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
void displaylist(struct node *head);
void createlist(struct node *head);
void searchlist(struct node *head);
void SearchAndReplacelist(struct node *head);
void insertlist(struct node *head);
void deletelist(struct node *head);
int main()
{
    int choice;
    system("cls");
    printf("___________________________________\n");
    printf("|C Programming | Abhishek V Adsul |\n");
    printf("|_________________________________|\n");
    printf("|           Linked Lists          |\n");
    printf("|_________________________________|");
    struct node *n1,*n2,*n3,*n4;
    n1=(struct node*)malloc(sizeof(struct node));
    n2=(struct node*)malloc(sizeof(struct node));
    n3=(struct node*)malloc(sizeof(struct node));
    n4=(struct node*)malloc(sizeof(struct node));

    n1->data=10;
    n2->data=20;
    n3->data=30;
    n4->data=40;

    n1->next=n2;
    n2->next=n3;
    n3->next=n4;
    n4->next=0;

    createlist(n1);

    int repeat=1;
    while(repeat!=0)
    {
    system("cls");
    displaylist(n1);
    printf("\n\n+---------------------------------+\n");
    printf("|MENU OPTIONS:                    |\n");
    printf("|1:Search occurances of element   |\n");
    printf("|2:Search and Replace element     |\n");
    printf("|3:Insert the element             |\n");
    printf("|4:Delete the element             |\n");
    printf("|5:end                            |\n");
    printf("+---------------------------------+\n\n");
    printf("Enter your option:");
    scanf("%d",&choice);

    switch(choice)
    {
        case 1:
        searchlist(n1);
        break;

        case 2:
        SearchAndReplacelist(n1);
        displaylist(n1);
        break;

        case 3:
        insertlist(n1);
        displaylist(n1);
        break;

        case 4:
        deletelist(n1);
        displaylist(n1);
        break;

        case 5:
        printf("\nThank you");
        repeat=0;
        break;

        default:
        {
            printf("You entered option is not in menu\n\n");
        }
    }
    if(choice!=5)
    {
    printf("\n_______________________________________");
    printf("\nDo you want to repeat (Yes=1 | No=0): ");
    scanf("%d",&repeat);
    }
    }
    printf("\n\n");
    return 0;
}
void displaylist(struct node *head)
{
    struct node *current;
    current = head;
    printf("\nLinked list -->");
    while(current!=0)
    {
        printf("%d",current->data);
        current=current->next;
        if(current!=0)
        {
            printf(" : ");
        }
    }
}
void createlist(struct node *head)
{
    struct node *current;
    current = head;
    int size, i=1;
    printf("\n\nEnter number of elements to create Linked List: ");
    scanf("%d",&size);
    while(i<=size)
    {
        printf("Enter elements %d: ",i);
        scanf("%d",&current->data);
        if(i==size)
        {
            current->next=0;
        }
        else
        {
            current->next=(struct node*)malloc(sizeof(struct node));
            current = current->next;
        }

        i++;
    }    
}
void searchlist(struct node *head)

{
    struct node *current;
    current = head;
    int count=0;
    char value;
    printf("\n\nEnter the element to search: ");
    scanf("%d",&value);
    while(current!=0)
    {
        if(current->data==value)
        {
            count++;
        }
        current=current->next;
    }
    printf("Number of occurances of No.%d are: %d",value,count);
}
void SearchAndReplacelist(struct node *head)

{
    struct node *current;
    current = head;
    int count=0;
    int value;
    int value2;
    printf("\n\nEnter the element to search: ");
    scanf("%d",&value);
    printf("\nEnter the element to replace(%d) : ",value);
    scanf("%d",&value2);
    while(current!=0)
    {
        if(current->data==value)
        {
            count++;
            current->data=value2;
        }
        current=current->next;
    }
    printf("\nNo of occurances of No.%d are: %d\n",value,count);
}
void insertlist(struct node *head)
{
    struct node *current;
    current = head;
    int length=0,position,value,i=1;

    while(current!=0)
    {
        length++;
        current = current->next;
    }
    current = head;

    printf("\n\nEnter position to insert (1-%d): ",length+1);
    scanf("%d",&position);
    printf("\n\nEnter value to insert: ");
    scanf("%d",&value);

    struct node *newnode;
    newnode = (struct node*)malloc(sizeof(struct node));
    
    if(position<=1)                 /*insert at head*/
    {
        position=1;
        newnode->data=current->data;
        newnode->next=current->next;
        current->data=value;
        current->next=newnode;
    }
    else if(position >= length+1)     /*insert at tail*/
    {
        position=length+1;
        while(current->next!=0)
        {
            current=current->next;
        }
        current->next = newnode;
        newnode->next=0;
        newnode->data=value;
    }
    else                            /*insert at random*/
    {
        while(i<position-1)
        {
            current = current->next;
            i++;
        }
        newnode->next = current->next;
        newnode->data = value;
        current->next = newnode;
    }

}
void deletelist(struct node *head)
{
    struct node *current;
    current = head;
    int length=0,position,i=1;

    while(current!=0)
    {
        length++;
        current = current->next;
    }
    current = head;

    printf("\n\nEnter position to delete (1-%d): ",length);
    scanf("%d",&position);

    struct node *trace;
    trace = (struct node*)malloc(sizeof(struct node));
    
    if(position<=1)                 /*delete at head*/
    {
        position = 1;
        trace = current->next;
        current->data = trace->data;
        current->next = trace->next;
        free(trace);

    }
    else if(position >= length)     /*insert at tail*/
    {
        position = length;
        while(current->next!=0)
        {
            trace =current;
            current = current->next;
        }
        trace->next = 0;
        free(current);
    }
    else                            /*insert at random*/
    {
        while(i<position)
        {
            trace = current;
            current = current->next;
            i++;
        }
        trace->next = current->next;
        free(current);
    }

}