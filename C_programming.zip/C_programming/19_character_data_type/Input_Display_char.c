#include<stdio.h>
#include<stdlib.h>
int main()
{
    char a;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------------\n");
    printf("Character datatype | Input and Display\n\n");
    printf("Enter a character: ");
    scanf("%c",&a);
    printf("Your entered character is: %c\n\n",a);
    printf("ASCII Value is: %d",a);
    printf("\n\n");
    return 0;

}