#include<stdio.h>
#include<stdlib.h>
void displaycharacter(char , int );

int main()
{
    char a;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------------\n");
    printf("Character datatype | ASCII Table\n\n");

    printf("ASCII values of a to z...\n");
    displaycharacter('a',26);
    printf("\n\n");

    printf("ASCII values of A to Z...\n");
    displaycharacter('A',26);
    printf("\n\n");

    printf("ASSCII values of 1 to 9 numbers...\n");
    displaycharacter('1',9);
    printf("\n\n");
    return 0;
}
void displaycharacter(char la,int lcount)
{
    for(int i=0; i < lcount; i++)
    {
        printf("%c = %3d \n",la,la);
        la++;
    }
}