#include<stdio.h>
#include<stdlib.h>
int main()
{
    char a;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------------\n");
    printf("Character datatype | Check character consonant or vowel\n\n");
    printf("Enter a character: ");
    scanf("%c",&a);
    if((a=='a') || (a=='e') || (a=='i') || (a=='o') || (a=='u'))
    {
        printf("%c is a vowel!\n",a);
    }

    else if((a=='A') || (a=='E') || (a=='I') || (a=='O') || (a=='U'))
    {
        printf("%c is a vowel!\n",a);
    }
    else
    {
        printf("%c is a consonant\n",a);
    }
    printf("\n\n");
    return 0;
}