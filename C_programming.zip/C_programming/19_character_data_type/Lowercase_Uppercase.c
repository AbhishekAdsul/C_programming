#include<stdio.h>
#include<stdlib.h>
int main()
{
    char a;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------------------\n");
    printf("Character datatype | Lowercase & Uppercase conversion\n\n");
    printf("Enter a character: ");
    scanf("%c",&a);
    if((a>=97)&&(a<=122))
    {
        printf("%c charater is in lower case\n",a);
        printf("Its UPPER CASE is: %c",a-32);
    }
    else if((a>=65)&&(a<=90))
    {
        printf("%c character is in UPPER CASE\n",a);
        printf("Its lower case is: %c",a+32);
    }
    else
    {
        printf("Invalid input\n");
    }
    printf("\n\n");
    return 0;

}