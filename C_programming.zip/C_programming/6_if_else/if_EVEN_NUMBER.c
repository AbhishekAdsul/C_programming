#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    int a;
    printf("C | Abhishek V Adsul\n");
    printf("---------------------\n");
    printf("if-EVEN NUMBER or ODD\n\n");
    printf("Enter a= ");
    scanf("%d",&a);
    if(a%2==0)
    {
        printf("Number a is Even\n\n");
    }
    else
    {
        printf("Number a is odd\n\n");
    }
    return 0;

}