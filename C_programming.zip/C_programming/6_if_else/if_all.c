#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------\n");
    printf("if_all possible conditions\n\n");
    int a,b;
    printf("Enter a: ");
    scanf("%d",&a);
    printf("Enter b: ");
    scanf("%d",&b);
    if(a==b) printf("a==b is true\n");
    if(a!=b) printf("a!=b is true\n");
    if(a>b) printf("a>b is true\n");
    if(b>a) printf("b>a is true\n");
    if(a>=b) printf("a>=b is true\n\n");
    if(a<=b) printf("a<=b is true\n\n");
    return 0;
}