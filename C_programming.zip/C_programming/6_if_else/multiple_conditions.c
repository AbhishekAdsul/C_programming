#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("----------------------------------\n");
    printf("if | Combining multiple conditions\n\n");
    int a;
    printf("Enter a: ");
    scanf("%d",&a);
    if(a>100 && a%2==0)
    {
        printf("a is greater than 100 and even\n");
    }
    else if(a<100 && a%2==0)
    {
        printf("a is less than 100 and even\n");
    }
    else if(a==100)
    {
        printf("a is equal to 100\n");
    }
    else
    {
        printf("a is odd\n");
    }
    return 0;
}