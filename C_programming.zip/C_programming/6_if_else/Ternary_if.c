#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------\n");
    printf("if | Ternary if statement\n\n");

    int a,b,max;
    printf("Enter a: ");
    scanf("%d",&a);
    printf("Enter b: ");
    scanf("%d",&b);
    max=(a>b)?a:b;
    printf("Biggest number between a and b is: %d\n\n",max);
    return 0;
}