#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("else_if | BIG NUMBER\n\n");
    int a,b;
    printf("Enter a: ");
    scanf("%d",&a);
    printf("Enter b: ");
    scanf("%d",&b);
    if(a>b)
    {
        printf("a is bigger\n\n");
    }
    else if(b>a)
    {
        printf("b is bigger\n\n");
    }
    else
    {
        printf("Both are equal");
    }
    return 0;
}