#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define count 4
struct student
{
    int rollno;
    char name[30];
    int marks;
    float percent;
    char grade;
};
struct student fe[count];
void askdata(void);
void calculategrade(void);
void showresult(void);
void filldata(void);
void showmenu(void);
void sortdata(void);

int i,j,k,temp,choice=1;
int main(void)
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("Structures in C\n\n");
    //askdata();
    filldata();
    calculategrade();
    while(choice<4)
    {
        sortdata();
        showresult();
        showmenu();
    }
    printf("\n\n");
    return 0;
}

void askdata(void)
{
    for(i=0;i<count;i++)
    {
        fe[i].rollno=i+1;
        printf("Roll No %d\n",fe[i].rollno);
        printf("Name: ");
        scanf("%s",fe[i].name);
        printf("Marks: ");
        scanf("%d",&fe[i].marks);
        printf("\n");
    }
}

void calculategrade(void)
{
    for(i=0;i<count;i++)
    {
        fe[i].percent=fe[i].marks/7.00;
        if(fe[i].percent<40)
        {
            fe[i].grade='F';
        }
        else
        if(fe[i].percent<50)
        {
            fe[i].grade='D';
        }
        else
        if(fe[i].percent<60)
        {
            fe[i].grade='C';
        }
        else
        if (fe[i].percent<75)
        {
            fe[i].grade='B';
        }
        else
        {
            fe[i].grade='A';
        }
    }
}
void showresult(void)
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("Structures in C\n\n");
    printf("---------------------------------------------------\n");
    printf("Rollno    Name        Marks     Percentage   Grade\n");
    printf("---------------------------------------------------\n");
    for(i=0;i<count;i++)
    {
        printf("%4d",fe[i].rollno);
        printf("\t%-15s",fe[i].name);
        printf("\t%3d",fe[i].marks);
        printf("%11.2f",fe[i].percent);
        printf("\t\t%c\n",fe[i].grade);
    }
    printf("---------------------------------------------------\n");
}

void filldata(void)



{
    i=0;
    fe[i].rollno=i+1;
    strcpy(fe[i].name,"Abhishek");
    fe[i].marks = 700;

    i++;
    fe[i].rollno=i+1;
    strcpy(fe[i].name,"Om");
    fe[i].marks = 480;

    i++;
    fe[i].rollno=i+1;
    strcpy(fe[i].name,"Vaibhav");
    fe[i].marks = 270;

    i++;
    fe[i].rollno=i+1;
    strcpy(fe[i].name,"Soham");
    fe[i].marks = 410;

}

void showmenu(void)

{
    printf("\nSort by...");
    printf("\n1:Roll No");
    printf("\n2:Name");
    printf("\n3:Marks");
    printf("\n4:Exit                   Enter your choice: ");
    scanf("%d",&choice);
}

void sortdata(void)
{
    struct student stemp;
    switch(choice)
    {
        case 1:
        for(i=0;i<count-1;i++)
        {
            for(j=0;j<count-1;j++)
            {
                if(fe[j].rollno>fe[j+1].rollno)
                {
                    stemp = fe[j];
                    fe[j] = fe[j+1];
                    fe[j+1] = stemp;
                }
            }
        }
        break;

        case 2:
        for(i=0;i<count-1;i++)
        {
            for(j=0;j<count-1;j++)
            {
                if(fe[j].name[0]>fe[j+1].name[0])
                {
                    stemp = fe[j];
                    fe[j] = fe[j+1];
                    fe[j+1] = stemp;
                }
            }
        }
        break;

        case 3:
        for(i=0;i<count-1;i++)
        {
            for(j=0;j<count-1;j++)
            {
                if(fe[j].marks<fe[j+1].marks)
                {
                    stemp = fe[j];
                    fe[j] = fe[j+1];
                    fe[j+1] = stemp;
                }
            }
        }
        break;

        default:
        break;
    }
}