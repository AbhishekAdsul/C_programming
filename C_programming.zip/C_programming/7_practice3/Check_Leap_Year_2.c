#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("------------------------------\n");
    printf("Check Year is Leap year or not\n\n");

    int year;
    printf("Enter the year: ");
    scanf("%d",&year);
    if((year%400==0)||((year%4==0)&&(year%100!=0)))
    {
        printf("The year %d is leap year\n",year);
    }
    else
    {
        printf("The year %d is not leap year\n",year);
    }
}
