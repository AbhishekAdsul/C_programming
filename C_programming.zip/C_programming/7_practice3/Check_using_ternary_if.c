#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------------------------------\n");
    printf("Check for positive,negative,zero using ternary if\n\n");
    int num;
    printf("Enter the number: ");
    scanf("%d",&num);
    
    (num>0)? printf("Number is positive\n"):(num<0)? printf("Number is negative\n"):printf("Number is equal to zero\n");

    return 0;
}