#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------\n");
    printf("Check for positive,negative,zero\n\n");
    int num;
    printf("Enter the number: ");
    scanf("%d",&num);
    
    if(num>0)
    {
        printf("Number is positive\n");
    }
    else if(num<0)
    {
        printf("Numter is negative\n");
    }
    else
    {
        printf("Number is equal to zero\n");
    }
    return 0;
}