#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("----------------------\n");
    printf("Menu driven calculator\n\n");

    int a,b,choice,add,diff,mult,quot,rem;
    printf("Enter a: ");
    scanf("%d",&a);
    printf("Enter b: ");
    scanf("%d",&b);
    printf("-------------------\n");
    printf("Menu Options:\n");
    printf("1:Addition\n");
    printf("2:Substraction\n");
    printf("3.Multiplication\n");
    printf("4.Division\n");
    printf("5.End\n");
    printf("-------------------\n\n");
    printf("Enter your choice: ");
    scanf("%d",&choice);
    if(choice==1)
    {
        add=a+b;
        printf("Addition is: %d\n",add);
    }
    else if(choice==2)
    {
        diff=a-b;
        printf("Substraction is: %d\n",diff);
    }
    else if(choice==3)
    {
        mult=a*b;
        printf("Multiplication is: %d\n",mult);
    }
    else if(choice==4)
    {
        quot=a/b;
        printf("Quotiont is : %d\n",quot);
        rem=a%b;
        printf("Remainder is : %d\n",rem);
    }
    else if(choice==5)
    {
        printf("Thank you\n");
    }
    else
    {
        printf("Invalid choice\n");
    }
    return 0;
}