#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------\n");
    printf("floor() , ceil() , round()\n\n");
    int a;
    float fa=3.95;

    a=fa;
    printf("default : %d\n",a);

    a=floor(fa);
    printf("floor: %d\n",a);

    a=ceil(fa);
    printf("ceil: %d\n",a);

    a=round(fa);
    printf("round: %d\n\n",a);

    return 0;


}