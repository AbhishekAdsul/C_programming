#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("Type_casting\n\n");

    int marks=25,outof=30;
    float fpercent;

    fpercent=(float)marks/outof*100;
    printf("Marks obtained=%d\n",marks);
    printf("Out of :%d\n",outof);
    printf("Percentage: %f\n\n",fpercent);

}