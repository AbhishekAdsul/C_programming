#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------\n");
    printf("Output of floating point numbers\n\n");

    float a;
    printf("Enter a: ");
    scanf("%f",&a);

    printf("a=%f\n",a);

    printf("a=%4.2f\n",a);

    printf("a=%4.0f\n",a);

    printf("a=%8.1f\n",a);

    printf("a=%g\n",a);

    printf("a=%8g\n",a);

    printf("a=%.0f\n",a);

    printf("a=%.2f\n",a);

    return 0;
}