#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------\n");
    printf("Range of double data type\n\n");

    float fa;
    double da;

    printf("Enter float number: ");
    scanf("%f",&fa);

    printf("Enter double number: ");
    scanf("%lf",&da);

    printf("fa= %f\n",fa);
    printf("da= %lf\n",da);

    printf("fa= %.0f\n",fa);
    printf("da= %.0lf\n",da);

    printf("-------------------------\n");
    printf("Range of double data type\n");

    fa=fa*1000000000;
    da=da*1000000000;
    printf("fa=%.0f\n",fa);
    printf("da=%.0lf\n\n",da);

    fa=fa*1000000000;
    da=da*1000000000;
    printf("fa=%.0f\n",fa);
    printf("da=%.0lf\n\n",da);

    fa=fa*1000000000;
    da=da*1000000000;
    printf("fa=%.0f\n",fa);
    printf("da=%.0lf\n\n",da);

    fa=fa*1000000000;
    da=da*1000000000;
    printf("fa=%.0f\n",fa);
    printf("da=%.0lf\n\n",da);

    fa=fa*1000000000;
    da=da*1000000000;
    printf("fa=%.0f\n",fa);
    printf("da=%.0lf\n\n",da);

    return 0;


}