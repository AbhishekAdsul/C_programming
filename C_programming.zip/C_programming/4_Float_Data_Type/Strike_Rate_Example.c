#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("|C | Abhishek V Adsul                  |\n");
    printf("|--------------------------------------|\n");
    printf("|Strike rate example using type casting|\n");
    printf("|--------------------------------------|\n\n");

    int runs,balls;
    float sr;
    runs=100;
    balls=30;

    sr=(float)runs/balls*100;
    printf("Runs scored by dhoni %d\n",runs);
    printf("balls played by dhoni %d\n",balls);
    printf("Strike Rate of Dhoni is: %f\n\n",sr);

    return 0;
}