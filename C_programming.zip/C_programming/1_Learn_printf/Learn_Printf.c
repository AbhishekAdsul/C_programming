/*Command used to clear the terminal:-
function prompt {'INPUT: '}*/

#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------\n");
    printf("Learn Printf() \n\n");

    printf("|-----------------------------------------------------------------------|\n");
    printf("|\tName\t\t\t|\tAge\t|\tContactNo\t|\n");
     printf("|-----------------------------------------------------------------------|\n");
    printf("|\tAbhishek Adsul\t\t|\t20\t|\t9325041394\t|\n");
    printf("|\tKartik Shinde\t\t|\t21\t|\t5645647892\t|\n");
    printf("|\tSoham Akhade\t\t|\t22\t|\t1254634567\t|\n");
    printf("|-----------------------------------------------------------------------|\n");


    printf("\n\n");
    return 0;
}