#include<stdio.h>
#include<stdlib.h>
int main()
{
    int num=0,rem=0,rev=0,temp=0;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------\n");
    printf("while loop | Palindrome\n\n");
    printf("Enter the number: ");
    scanf("%d",&num);
    temp=num;
    while(num!=0)
    {
        rem=num%10;
        rev=(rev*10)+rem;
        num=num/10;
    }
    printf("Reversed Number: %d",rev);
    if(temp==rev)
    {
        printf("\n\nIt is a palindrome");
    }
    else
    {
        printf("\n\nIt is not a palindrome");
    }
    printf("\n\n");
    return 0;
}
