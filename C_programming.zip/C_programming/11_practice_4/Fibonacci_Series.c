#include<stdio.h>
#include<stdlib.h>
int main()
{
    int repeat=1;
    while(repeat!=0)
    {
    int a=0,b=1,c=0,max=0;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("while loop | Fibonacci Series\n\n");
    printf("Enter the max number: ");
    scanf("%d",&max);
    if(max==0)
    {
        printf("Fibonacci Series:0\n");
    }
    else{
    printf("Fibonacci Series:0 1\t");
    c=a+b;
    while(c<=max)
    {
        printf("%d\t",c);
        a=b;
        b=c;
        c=a+b;
    }
    }
    printf("\nDo you want to continue(YES=1 | NO=0): ");
    scanf("%d",&repeat);
    }
    printf("\n\n");
    return 0;
}