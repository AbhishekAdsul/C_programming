#include<stdio.h>
#include<stdlib.h>
int main()
{
    int num,bit;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("While loop | Decimal to binary conversion\n\n");
    printf("Enter the number: ");
    scanf("%d",&num);
    printf("Binary Conversion is.....\n");
    if(num==0)
    {
        printf("0\n");
    }

    while(num!=0)
    {
        bit=num%2;
        printf("%d\n",bit);
        num=num/2;
    }
    return 0;
}