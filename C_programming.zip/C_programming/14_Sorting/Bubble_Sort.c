#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,j,count,temp;
    int arrnum[20];
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------\n");
    printf("Sorting Arrays | Bubble sort\n\n");
    printf("Enter the number of elements: ");
    scanf("%d",&count);
    printf("\nEnter %d numbers...\n",count);
    for(i=0;i<count;i++)
    {
        printf("[%d]: ",i);
        scanf("%d",&arrnum[i]);
    }
    printf("Your entered numbers are...\n");
    for(i=0;i<count;i++)
    {
        printf("%4d ",arrnum[i]);
    }
    for(i=0;i<count-1;i++)
    {
        for(j=0;j<count-1-i;j++)
        {
            if(arrnum[j]>arrnum[j+1])
            {
                temp=arrnum[j];
                arrnum[j]=arrnum[j+1];
                arrnum[j+1]=temp;
            }
        }
    }
    printf("\n\nAscending order numbers are...\n");
    for(i=0;i<count;i++)
    {
        printf("%4d ",arrnum[i]);
    }
    
    for(i=0;i<count-1;i++)
    {
        for(j=0;j<count-1-i;j++)
        {
            if(arrnum[j]<arrnum[j+1])
            {
                temp=arrnum[j];
                arrnum[j]=arrnum[j+1];
                arrnum[j+1]=temp;
            }
        }
    }
    printf("\n\ndiscending order numbers are...\n");
    for(i=0;i<count;i++)
    {
        printf("%4d ",arrnum[i]);
    }

    printf("\n\n");
    return 0;
}