#include<stdio.h>
#include<stdlib.h>
void displaycharacter(char , int );

int main()
{
    int a=25;
    int *ptra=&a;

    long int la=30;
    long int *ptrla=&la;

    float fa=35.25;
    float *ptrfa=&fa;

    double da=40;
    double *ptrda=&da;

    char ca='A';
    char *ptrca=&ca;

    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------------------\n");
    printf("Pointers | Declaration of pointer\n\n");

    printf("=================================\n");
    printf("int pointer:\n\n");
    printf("a= %d\n",a);   //value of a
    printf("&a= %p\n\n",&a);  //address of a
    printf("*ptra= %d\n",*ptra);  //value of a
    printf("ptra= %p\n",ptra);   //address of a
    printf("=================================\n");

    printf("long int pointer:\n\n");
    printf("la= %ld\n",la);   //value of la
    printf("&la= %p\n\n",&la);  //address of la
    printf("*ptrla= %ld\n",*ptrla);  //value of la
    printf("ptrla= %p\n",ptrla);   //address of la
    printf("=================================\n");

    printf("float pointer:\n\n");
    printf("fa= %.2f\n",fa);   //value of la
    printf("&fa= %p\n\n",&fa);  //address of la
    printf("*ptrfa= %.2f\n",*ptrfa);  //value of la
    printf("ptrfa= %p\n",ptrfa);   //address of la
    printf("=================================\n");

    printf("double pointer:\n\n");
    printf("da= %.2f\n",da);   //value of la
    printf("&da= %p\n\n",&da);  //address of la
    printf("*ptrda= %.2f\n",*ptrda);  //value of la
    printf("ptrda= %p\n",ptrda);   //address of la
    printf("=================================\n");
    
    printf("character pointer:\n\n");
    printf("ca= %c\n",ca);   //value of la
    printf("&ca= %p\n\n",&ca);  //address of la
    printf("*ptrca= %c\n",*ptrca);  //value of la
    printf("ptrca= %p\n",ptrca);   //address of la
    printf("=================================\n");
    
    printf("\n\n");
    return 0;

}