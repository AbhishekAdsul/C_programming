#include<stdio.h>
#include<stdlib.h>
void displaycharacter(char , int );

int main()
{
    int a=25;
    int *ptra=&a;

    long int la=30;
    long int *ptrla=&la;

    float fa=35.25;
    float *ptrfa=&fa;

    double da=40;
    double *ptrda=&da;

    char ca='A';
    char *ptrca=&ca;

    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------------------\n");
    printf("Pointers | Declaration of pointer\n\n");

    printf("=================================\n");
    printf("int pointer:\n\n");
    printf("ptra= %p\n",ptra++);   //address of a
    printf("ptra= %p\n",ptra);     //address of a + 4 byte
    printf("=================================\n");

    printf("long int pointer:\n\n");
    printf("ptrla= %p\n",ptrla++);   //address of la
    printf("ptrla= %p\n",ptrla);   //address of la + 8 byte
    printf("=================================\n");

    printf("float pointer:\n\n");
    printf("ptrfa= %p\n",ptrfa++);   //address of fa
    printf("ptrfa= %p\n",ptrfa);   //address of fa + 4 byte
    printf("=================================\n");

    printf("double pointer:\n\n");
    printf("ptrda= %p\n",ptrda++);   //address of da
    printf("ptrda= %p\n",ptrda);     //address of da + 8 byte
    printf("=================================\n");
    
    printf("character pointer:\n\n");
    printf("ptrca= %p\n",ptrca++);   //address of la
    printf("ptrca= %p\n",ptrca);   //address of la + 1 byte
    printf("=================================\n");
    
    printf("\n\n");
    return 0;

}