#include<stdio.h>
#include<stdlib.h>
#include<string.h> //Contains strlen(),etc.
int main()
{
    char str1[100];
    int count,i,j,temp,flag=1;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------------------------------------\n");
    printf("Strings | Without reversing string check palindrome\n\n");
    printf("Enter the string: ");
    fgets(str1,100,stdin);
    count=strlen(str1)-1;
    for(i=0;i<count/2;i++)
    {
        if(str1[i]!=str1[count-1-i])
        {
            flag=0;
        }
    }
    if(flag==1)
    {
        printf("\nYES | It's a palindrome\n");
    }
    else
    {
        printf("\nNo | It's not a palindrome\n");
    }
    printf("\n\n");
    return 0;
}