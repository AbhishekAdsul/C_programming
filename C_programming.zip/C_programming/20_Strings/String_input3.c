#include<stdio.h>
#include<stdlib.h>
#include<string.h> //Contains strlen(),etc.
int main()
{
    char strname[100];
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("--------------------------------------------\n");
    printf("Strings | Input the string using fgets() & %s\n\n");
    printf("Enter your name: ");
    fgets(strname,100,stdin);
    printf("\nYour name is: %s",strname);
    printf("\n\n");
    return 0;
}