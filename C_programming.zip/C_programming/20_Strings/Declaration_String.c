#include<stdio.h>
#include<stdlib.h>
#include<string.h> //Contains strlen(),etc.
int main()
{
    char str1[]={"Abhishek"};
    char str2[10]={'A','d','s','u','l','\0'};
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------------------------\n");
    printf("Strings | Declaration and Display of String \n\n");

    printf("1: %s\n",str1);
    printf("Size: %lu\n",sizeof(str1));
    printf("Length: %lu\n\n",strlen(str1));

    printf("2: %s\n",str2);
    printf("Size: %lu\n",sizeof(str2));
    printf("Length: %lu\n\n",strlen(str2));

    printf("\n\n");

    return 0;
}