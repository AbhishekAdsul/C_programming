#include<stdio.h>
#include<stdlib.h>
#include<string.h> //Contains strlen(),etc.
int main()
{
    char str1[100];
    int count,i,j,temp;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------------\n");
    printf("Strings | Sorting of string\n\n");
    printf("Enter the string: ");
    fgets(str1,100,stdin);
    count=strlen(str1)-1;
    for(i=0;i<count-1;i++)
    {
        for(j=0;j<count-1;j++)
        {
            if(str1[j]>str1[j+1])
            {
                temp=str1[j];
                str1[j]=str1[j+1];
                str1[j+1]=temp;
            }
        }
    
    }
    printf("\n\nSorted String is: %s",str1);



    printf("\n\n");
    return 0;
}