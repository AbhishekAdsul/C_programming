#include<stdio.h>
#include<stdlib.h>
#include<string.h> //Contains strlen(),etc.
int main()
{
    char str1[100];
    char str2[100];
    int count,i,j,temp,flag=1;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------------------\n");
    printf("Strings | Reversing a string & check palindrome\n\n");
    printf("Enter the string: ");
    fgets(str1,100,stdin);
    count=strlen(str1)-1;
    for(i=0;i<count;i++)
    {
        str2[i]=str1[count-1-i];
    }
    printf("\nReveresed String is: %s",str2);

    for(i=0; i<count; i++)
    {
        if(str1[i]!=str2[i])
        {
            flag=0;
        }
    }

    if(flag==1)
    {
        printf("\n\nYES | It's a palindrome!\n");
    }
    else
    {
        printf("\n\nNo | It's not a palindrome\n");
    }

    printf("\n\n");
    return 0;
}