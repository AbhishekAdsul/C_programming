#include<stdio.h>
#include<stdlib.h>
#include<string.h> //Contains strlen(),etc.
int main()
{
    char str1[100];
    char str2[100];
    int count,i,j,temp;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("----------------------------\n");
    printf("Strings | Reversing a string\n\n");
    printf("Enter the string: ");
    fgets(str1,100,stdin);
    count=strlen(str1)-1;
    for(i=0;i<count;i++)
    {
        str2[i]=str1[count-1-i];
    }
    printf("Reveresed String is: %s",str2);
    printf("\n\n");
    return 0;
}