#include<stdio.h>
#include<stdlib.h>
#define max 10
int main()
{
    int a[max][max];
    int b[max][max];
    int c[max][max];
    int arows,acols,brows,bcols,crows,ccols;
    int i,j,k,temp;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("---------------------------------\n");
    printf("2D Arrays | Matrix Multiplication\n\n");

    printf("\nEnter size of matrix A\n");
    printf("Rows: ");
    scanf("%d",&arows);
    printf("Columns: ");
    scanf("%d",&acols);

    printf("\nEnter size of matrix B\n");
    brows=acols;
    printf("Rows: %d\n",brows);
    printf("Columns: ");
    scanf("%d",&bcols);

    crows=arows;
    ccols=bcols;

    printf("Enter elements of Matrix A...\n");
    for(i=0;i<arows;i++)
    {
        for(j=0;j<acols;j++)
        {
            printf("[%d][%d]: ",i,j);
            scanf("%d",&a[i][j]);
        }
        printf("\n");
    }

    printf("Enter elements of Matrix B...\n");
    for(i=0;i<brows;i++)
    {
        for(j=0;j<bcols;j++)
        {
            printf("[%d][%d]: ",i,j);
            scanf("%d",&b[i][j]);
        }
        printf("\n");
    }


    for (i = 0; i < ccols; i++)
    {
        for(j = 0; j < ccols; j++)
        {
            c[i][j]=0;
            for(k = 0; k < acols; k++)
            {
                c[i][j]+=a[i][k]*b[k][j];
            }
        }
    }

    system("cls");
    printf("2D Arrays | Matrix Multiplication\n\n");

    printf("Matrix A:\n\n");
    for(i=0;i<arows;i++)
    {
        printf("          |");
        for(j=0;j<acols;j++)
        {
            printf("%4d ",a[i][j]);
        }
        printf("   |");
        printf("\n");
    }

    printf("\nMatrix B:\n\n");
    for(i=0;i<brows;i++)
    {
        printf("          |");
        for(j=0;j<bcols;j++)
        {
            printf("%4d ",b[i][j]);
        }
        printf("   |");
        printf("\n");
    }

    printf("\n\nMatrix C (Matrix A * Matrix B): \n\n");
    for(i=0;i<crows;i++)
    {
        printf("          |");
        for(j=0;j<ccols;j++)
        {
            printf("%4d ",c[i][j]);
        }
        printf("   |");
        printf("\n");
    }
    

    printf("\n\n");

}