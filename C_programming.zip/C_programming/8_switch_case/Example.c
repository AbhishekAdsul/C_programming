#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("----------------------\n");
    printf("Switch case example\n\n");
    int a;
    printf("Enter a: ");
    scanf("%d",&a);
    switch(a)
    {
        case 1 :
        {
            printf("\na=%d\n\n",a);
            break;
        }
        case 2 :
        {
            printf("\na=%d\n\n",a);
            break;
        }
        case 3 :
        {
            printf("\na=%d\n\n",a);
            break;
        }
        default:
        {
            printf("\na is different from 1,2,3\n\n");
        }
    }
    return 0;
}