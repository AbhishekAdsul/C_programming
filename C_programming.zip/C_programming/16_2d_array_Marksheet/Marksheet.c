//input marks
//process the data
//Display marksheet
//Display Best Subjects
#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,j,temp=0,total=0,percentage;
    int arrmarks[6][4]={0};
    int indext=0,indexv=0,indexl=0,indextotal=0;
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("------------------------------\n");
    printf("2D Arrays | Marksheet\n\n");
    printf("\nMarksheet - Semester 4\n\n");

    for(i=0;i<6;i++)
    {
        temp=0;
        printf("\nEnter Marks for Sub %d  \n",i+1);
        printf("Theory: ");
        scanf("%d",&arrmarks[i][0]);
        temp=temp+arrmarks[i][0];
        printf("Viva: ");
        scanf("%d",&arrmarks[i][1]);
        temp=temp+arrmarks[i][1];
        printf("Lab: ");
        scanf("%d",&arrmarks[i][2]);
        temp=temp+arrmarks[i][2];
        arrmarks[i][3]= temp;
        printf("\n");
    }
    system("cls");
    printf("\nMarksheet - Semester 4\n\n");
    printf("Subject     Theory    Viva      Lab     Total\n");
    printf("---------------------------------------------\n");
    for(i=0;i<6;i++)
    {
        printf("Sub %d  ",i+1);
        for(j=0;j<4;j++)
        {
            printf("      %3d",arrmarks[i][j]);
        }
        printf("\n");
    }
    printf("---------------------------------------------\n");
    for(i=0;i<6;i++)
    {
        total=total+arrmarks[i][3];
    }
    printf("Total                                 %6d\n\n",total);
    percentage=total/6;
    printf("Percentage                           %6d%%\n\n",percentage);
    temp=0;
    for(i=0;i<6;i++)
    {
        if(arrmarks[i][0]>temp)
        {
            temp=arrmarks[i][0];
            indext=i;
        }
    }
    printf("Best in theory                         Sub %d\n",++indext);

    
    temp=0;
    for(i=0;i<6;i++)
    {
        if(arrmarks[i][1]>temp)
        {
            temp=arrmarks[i][1];
            indexv=i;
        }
    }
    printf("Best in Viva                           Sub %d\n",++indexv);

    temp=0;
    for(i=0;i<6;i++)
    {
        if(arrmarks[i][2]>temp)
        {
            temp=arrmarks[i][2];
            indexl=i;
        }
    }
    printf("Best in Practical                      Sub %d\n",++indexl);

    temp=0;
    for(i=0;i<6;i++)
    {
        if(arrmarks[i][3]>temp)
        {
            temp=arrmarks[i][3];
            indextotal=i;
        }
    }
    printf("Best in Overall                        Sub %d\n",++indextotal);
}