#include<stdio.h>
#include<stdlib.h>

int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-------------------------------\n");
    printf("Learn Scanf()\n\n");

    int a,b,c;
    printf("Enter a:");
    scanf("%d",&a);
    printf("Enter b:");
    scanf("%d",&b);

    printf("\nResults....\n\n");
    printf("Value of a:%d\n",a);
    printf("Value of b:%d\n",b);

    c=a+b;
    printf("ADD | a+b = %d\n",c);

    c=a-b;
    printf("SUB | a-b = %d\n",c);

    c=a*b;
    printf("MUL | a*b = %d\n",c);

    c=a/b;
    printf("DIV | a/b = %d(Q)\n",c);

    c=a%b;
    printf("MOD | a/b = %d(R)\n",c);

    printf("\n\n");

    return 0;

}