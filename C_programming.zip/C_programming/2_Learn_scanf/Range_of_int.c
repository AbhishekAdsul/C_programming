#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------\n");
    printf("Range of int data type is (+ or -)2 billion\n\n");

    int a = -2;
    printf("Value of a:%d\n",a);

    a=a*10;
    printf("value of a:%d\n",a);
    a=a*10;
    printf("value of a:%d\n",a);
    a=a*10;
    printf("value of a:%d\n\n",a);

    a=a*10;
    printf("value of a:%d\n",a);
    a=a*10;
    printf("value of a:%d\n",a);
    a=a*10;
    printf("value of a:%d\n\n",a);

    a=a*10;
    printf("value of a:%d\n",a);
    a=a*10;
    printf("value of a:%d\n",a);
    a=a*10;
    printf("value of a:%d\n\n",a);

    printf("Range of signed int data type is (+ or -) 2 billion:%d\n",a);

    return 0;

}