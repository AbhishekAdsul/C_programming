#include<stdio.h>
#include<stdlib.h>
int main()
{
    system("cls");
    printf("C | Abhishek V Adsul\n");
    printf("-----------------------------------\n");
    printf("Range of unsigned int data type is +4 billion\n\n");

    int a = 4;
    printf("Value of a:%u\n",a);

    a=a*10;
    printf("value of a:%u\n",a);
    a=a*10;
    printf("value of a:%u\n",a);
    a=a*10;
    printf("value of a:%u\n\n",a);

    a=a*10;
    printf("value of a:%u\n",a);
    a=a*10;
    printf("value of a:%u\n",a);
    a=a*10;
    printf("value of a:%u\n\n",a);

    a=a*10;
    printf("value of a:%u\n",a);
    a=a*10;
    printf("value of a:%u\n",a);
    a=a*10;
    printf("value of a:%u\n\n",a);

    printf("Range of unsigned int data type is +4 billion:%u\n",a);

    return 0;

}